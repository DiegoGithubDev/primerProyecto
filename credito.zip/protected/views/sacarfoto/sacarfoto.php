<h1> capturando imagen fotografica </h1>


<div class="row buttons">
    <?php echo CHtml::submitButton('NewPhoto'); ?>
</div>