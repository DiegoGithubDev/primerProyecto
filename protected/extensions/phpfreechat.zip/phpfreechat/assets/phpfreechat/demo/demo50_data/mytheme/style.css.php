img.pfc_nickwhois_avatar {
  margin: 10px;
}