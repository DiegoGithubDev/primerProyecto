<html>
    <head>
        <link />
        <title>mi plantilla</title>
    </head>
    <body>
        <div class="header">
            SOY EL HEADER
        </div>
        <div class="container">
            <div class="row">
                <div class="span3">

                </div>
                <div class="span9">

                </div>
            </div>
        </div>
        <div class="footer">
            SOY EL FOOTER
        </div>
    </body>
</html>
