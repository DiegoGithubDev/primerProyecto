  <?php /* @var $this Controller */ ?>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
        <meta name="language" content="en">

        <?php /* ?>
          <!-- blueprint CSS framework -->
          <link rel="stylesheet" type="text/css" href="<?php echo Yii::app()->request->baseUrl; ?>/css/screen.css" media="screen, projection">
          <link rel="stylesheet" type="text/css" href="<?php echo Yii::app()->request->baseUrl; ?>/css/print.css" media="print">
          <!--[if lt IE 8]>
          <link rel="stylesheet" type="text/css" href="<?php echo Yii::app()->request->baseUrl; ?>/css/ie.css" media="screen, projection">
          <![endif]-->

          <link rel="stylesheet" type="text/css" href="<?php echo Yii::app()->request->baseUrl; ?>/css/main.css">
          <link rel="stylesheet" type="text/css" href="<?php echo Yii::app()->request->baseUrl; ?>/css/form.css">
          <?php */ ?>

        <link rel="stylesheet" type="text/css" href="<?php echo Yii::app()->request->baseUrl; ?>/css/style.css">

        <title><?php echo CHtml::encode($this->pageTitle); ?></title>

        <?php Yii::app()->bootstrap->register(); ?>


    </head>

    <body>
            <?php
            $this->widget('bootstrap.widgets.TbNavbar', array(
                'color' => TbHtml::NAVBAR_COLOR_INVERSE,
                'collapse' => true,
                'brandLabel' => Yii::app()->name,
                'display' => null,
                'items' => array(
                    array(
                        'class' => 'bootstrap.widgets.TbNav',
                        'items' => array(
                            array('label' => 'Home', 'url' => array('/site/index')),
                            array('label' => 'About', 'url' => array('/site/page', 'view' => 'about')),
                            array('label' => 'Contact', 'url' => array('/site/contact')),
                            array(
                                'label' => 'sacar foto',
                                'url' => array('/SacarFoto/index'),
                                'visible' => Yii::app()->user->isGuest,
                            ),
                            array(
                                'label' => 'Usuarios',
                                'url' => array('/usuario/admin'),
                                'visible' => !Yii::app()->user->isGuest,
                            ),
                            array(
                                'label' => 'Posts',
                                'url' => array('/post/index'),
                                'visible' => !Yii::app()->user->isGuest,
                            ),

                            array(
                                'label' => 'Categorias',
                                'url' => array('/category/admin'),
                                'visible' => !Yii::app()->user->isGuest,
                            ),
                            
                             array(
                                'label' => 'subir imagen',
                                'url' => array('/site/imagen'),
                                'visible' => Yii::app()->user->isGuest,
                            ),
                            
                             array(
                                'label' => 'perfil',
                                'url' => array('/category/admin'),
                                'visible' => !Yii::app()->user->isGuest,
                            ),
                            
                            array('label' => 'Dropdown', 'items' => array(
                                array('label' => 'Action', 'url' => '#'),
                                array('label' => 'Another action', 'url' => '#'),
                                array('label' => 'Something else here', 'url' => '#'),
                                TbHtml::menuDivider(),
                                array('label' => 'Separate link', 'url' => '#'),
                            )),
                
                            //+++++++esto es del tutorial++++++++++++++++++++++++
                            array('label'=>'panel de control','visible'=>!Yii::app()->user->isGuest,'url' => array('/usuario/upload'),),
                            array('label' => 'Login', 'url' => array('/site/login'), 'visible' => Yii::app()->user->isGuest),
                            array('label' => 'Logout (' . Yii::app()->user->name . ')', 'url' => array('/site/logout'), 'visible' => !Yii::app()->user->isGuest)
                           
                        ),
                    ),
                ),
            ));
            ?>
       
        <div class="container"  >

            <?php if (isset($this->breadcrumbs)): ?>
                <?php
                $this->widget('bootstrap.widgets.TbBreadcrumb', array(
                    'links' => $this->breadcrumbs,
                ));
                ?><!-- breadcrumbs -->
            <?php endif ?>

            <!--<div class="row">-->
             
                <?php echo $content; ?>
        </div>
            
        <div class="clear"> </div>
            <!--</div>-->
        <!-- page -->
        
        <!-- footer -->
        <div class="footer">
            Copyright &copy; <?php echo date('Y'); ?> by My Company.<br/>
            All Rights Reserved por diego mansilla.<br/>
            <?php echo Yii::powered(); ?>
        </div>
       
                 
    </body>
   
    
</html>
